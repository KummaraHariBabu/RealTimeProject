import React from 'react'

const Cources = () => {
  return (
    <div>Cources</div>
  )
}

export default Cources